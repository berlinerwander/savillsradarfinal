/* Savills Radar — Netlify Function (Drop build, Claude backend)
   SELF-CONTAINED: zero imports, zero npm deps (Drop runs no build step).
   Credential resolution order:
     1. Netlify AI Gateway — injects ANTHROPIC_API_KEY + ANTHROPIC_BASE_URL
     2. Your own key — set ANTHROPIC_API_KEY yourself (gateway then backs off)
     3. Neither — stub mode: canned, clearly-labelled sample output so the
        demo never shows a dead button. Force with STUB_AI=always. */

const GATEWAY_BASE = (process.env.ANTHROPIC_BASE_URL || "").replace(/\/+$/, "");
const API_URL = (GATEWAY_BASE || "https://api.anthropic.com") + "/v1/messages";
const MODEL = process.env.CLAUDE_MODEL || "claude-sonnet-4-6";
const BUDGET_MS = Number(process.env.AI_BUDGET_MS || 8500);
const KEY = process.env.ANTHROPIC_API_KEY;
const FORCE_STUB = process.env.STUB_AI === "always";

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json", "cache-control": "no-store" },
  });
}

function unauthorized(req) {
  const secret = process.env.RADAR_API_SECRET;
  if (!secret) return null;
  if (req.headers.get("x-radar-key") === secret) return null;
  return json({ error: "Unauthorized" }, 401);
}

const hits = new Map();
function rateLimited(req, max = 20, windowMs = 60000) {
  const ip = (req.headers.get("x-nf-client-connection-ip") ||
    (req.headers.get("x-forwarded-for") || "").split(",")[0] || "unknown").trim();
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter((t) => now - t < windowMs);
  if (recent.length >= max) return json({ error: `Rate limit: ${max} requests/min.` }, 429);
  recent.push(now);
  hits.set(ip, recent);
  if (hits.size > 500) hits.clear();
  return null;
}

/* Honest canned outputs, keyed by what the prompt is trying to do. */
function pickStub(prompt = "", system = "") {
  const p = prompt.toLowerCase(), sys = (system || "").toLowerCase();
  if (sys.includes("consumer ai assistant") || sys.includes("prospective commercial tenant"))
    return "For commercial leasing in Singapore, most tenants start with PropertyGuru Commercial for listings, then engage a brokerage such as CBRE or JLL for advisory and negotiation. Knight Frank and Colliers also cover office, retail and industrial mandates. For warehouse space specifically, CommercialGuru and JTC's portal list availability directly.";
  if (p.includes("opportunity digest"))
    return "MARKET PULSE: US and Korean brands are entering Singapore faster than local landlords are listing prime units.\n\n1. CHIPOTLE — first-touch this week. Entry confirmed for 2026 with no public site yet; open with off-market Orchard frontage (Orchard Gateway, 2,900 sq ft).\n2. LOTTE SHOPPING — route via the Korea desk. International HQ decision window is now; lead with Asia Square T2 and the EDB RHQ angle.\n3. MICRON ECOSYSTEM — pitch contractor staging packages near Woodlands North Coast before mobilisation peaks.\n\nWATCH: Pandora headcount vs its 8,600 sq ft — upsize trigger likely around month 9.";
  if (p.includes("cold email") || p.includes("outreach"))
    return "Subject: Space options ahead of your Singapore expansion\n\nHello — I lead the relevant desk at Savills Singapore. Your recent expansion announcement suggests a space decision is forming, and two options matching your likely requirement are moving before they list publicly. Happy to share a one-page comparison — rents, availability and fit-out state — with no obligation. Would a 20-minute call this week be useful?\n\nBest regards,\nSavills Singapore";
  if (p.includes("engagement brief"))
    return "The account is signalling a live space decision: public announcements point to a requirement forming within the stated window. The requirement shape matches mid-band options already in the matched list, so lead with a concrete comparison rather than a capability pitch. Best approach is the warmest route on file — referral or ecosystem intro beats cold outreach here. Qualify early whether budget authority sits locally or at HQ; that is the main risk to timeline.";
  return "Sample output (offline mode). Enable Netlify AI Gateway or set ANTHROPIC_API_KEY to generate live responses.";
}

async function claude({ prompt, system, search = false, maxTokens = 1200 }) {
  if (FORCE_STUB || !KEY) return { text: pickStub(prompt, system), stub: true };

  const body = {
    model: MODEL,
    max_tokens: maxTokens,
    messages: [{ role: "user", content: prompt }],
  };
  if (system) body.system = system;
  if (search) body.tools = [{ type: "web_search_20250305", name: "web_search" }];

  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), BUDGET_MS);
  try {
    const r = await fetch(API_URL, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify(body),
      signal: ac.signal,
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) {
      const msg = data?.error?.message || `Claude API error ${r.status}`;
      const e = new Error(msg);
      e.status = r.status === 429 ? 429 : 502;
      throw e;
    }
    const text = (data.content || []).filter((b) => b.type === "text").map((b) => b.text || "").join("\n").trim();
    if (!text) throw Object.assign(new Error("Empty response from Claude"), { status: 502 });
    return { text, stub: false };
  } catch (e) {
    if (e.name === "AbortError") {
      const err = new Error(`Claude did not respond within ${(BUDGET_MS / 1000).toFixed(1)}s (Netlify 10s function cap). Web-search calls are the slow ones.`);
      err.status = 504;
      throw err;
    }
    throw e;
  } finally {
    clearTimeout(timer);
  }
}

export default async () =>
  json({
    ok: true,
    provider: "anthropic",
    model: MODEL,
    keySet: Boolean(KEY),
    mode: FORCE_STUB ? "stub-forced" : GATEWAY_BASE ? "netlify-ai-gateway" : KEY ? "own-anthropic-key" : "stub-no-credential",
    budgetMs: BUDGET_MS,
    runtime: "netlify-functions (drop build)",
  });
